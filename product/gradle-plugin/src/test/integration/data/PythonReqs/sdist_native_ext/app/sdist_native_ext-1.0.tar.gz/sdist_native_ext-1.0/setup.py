from setuptools import Extension, find_packages, setup

setup(
    name="sdist_native_ext",
    version="1.0",
    ext_modules=[Extension("ext_module", ["ext_module.c"])]
)
