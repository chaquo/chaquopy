# pure and armeabi-v7a
