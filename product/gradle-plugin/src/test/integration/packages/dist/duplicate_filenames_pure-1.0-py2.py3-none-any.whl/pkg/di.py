# pure
