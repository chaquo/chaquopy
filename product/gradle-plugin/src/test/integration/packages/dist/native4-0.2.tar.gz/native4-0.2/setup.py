from setuptools import setup
import os
from os.path import dirname, exists, join
import sys

# This script can be used to build wheels, but will fail to install from an sdist.
if "install" in sys.path:
    raise Exception("Simulate install failure")

# Generate dists as follows. Don't forget to include "clean" or things may leak from one build
# to the next.
#     python setup.py clean {sdist|bdist_wheel} <name> <version> <package-suffix>
suffix = sys.argv.pop()
version = sys.argv.pop()
name = sys.argv.pop()

pkg_name = "{}_{}".format(name, suffix)
src_dir = join(dirname(__file__), pkg_name)
if not exists(src_dir):
    os.mkdir(src_dir)
    with open(join(src_dir, "__init__.py"), "w"):
        pass

setup(
    name=name,
    version=version,
    packages=[pkg_name]
)
