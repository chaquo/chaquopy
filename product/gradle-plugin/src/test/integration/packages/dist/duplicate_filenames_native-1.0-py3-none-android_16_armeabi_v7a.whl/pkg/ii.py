# pure, armeabi-v7a and x86
