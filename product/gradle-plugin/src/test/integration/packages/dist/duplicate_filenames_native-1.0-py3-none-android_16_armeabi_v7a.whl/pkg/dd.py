# armeabi-v7a ######
