from java import *


class ReqsB1(static_proxy()): pass
