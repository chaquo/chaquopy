from java import static_proxy


class ReqsB1(static_proxy()):
    pass
