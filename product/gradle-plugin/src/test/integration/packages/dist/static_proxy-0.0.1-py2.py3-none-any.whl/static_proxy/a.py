from java import *


class ReqsA1(static_proxy()): pass
