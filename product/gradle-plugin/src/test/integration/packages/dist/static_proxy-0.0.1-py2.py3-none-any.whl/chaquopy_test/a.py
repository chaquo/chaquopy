from java import static_proxy


class ReqsA1(static_proxy()):
    pass
