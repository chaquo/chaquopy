
from setuptools import setup
import sys

setup(
    name="no_binary",
    version="1.0",
    packages=["no_binary_sdist"]
)
