from setuptools import setup, find_packages

setup(
    name="sdist1",
    version="0.2",
    packages=find_packages(),
)
